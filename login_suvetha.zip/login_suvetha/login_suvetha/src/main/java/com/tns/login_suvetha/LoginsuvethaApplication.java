package com.tns.login_suvetha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginsuvethaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginsuvethaApplication.class, args);
	}

}
